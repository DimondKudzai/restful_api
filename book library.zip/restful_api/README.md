
A full-stack basic book library app built with Go, JavaScript, and HTML/CSS.

*Features*

- Create, read, update, and delete (CRUD) book entries


*Technologies Used*

- Go
- HTML/CSS
- JavaScript


*License*

MIT License

Your're free to use and share this app's code with anyone who might need it.

Your feedback is important.

diamondkudzai70@gmail.com